// Export pages
export 'home_page/home_page_widget.dart' show HomePageWidget;
export 'signup2/signup2_widget.dart' show Signup2Widget;
export 'perfil/perfil_widget.dart' show PerfilWidget;
export 'newfeed/newfeed_widget.dart' show NewfeedWidget;
export 'publicacao/publicacao_widget.dart' show PublicacaoWidget;
export 'novapublicacao/novapublicacao_widget.dart' show NovapublicacaoWidget;
export 'content/content_widget.dart' show ContentWidget;
export 'shopping/shopping_widget.dart' show ShoppingWidget;
export 'saibamais/saibamais_widget.dart' show SaibamaisWidget;
